#------------------Version 1.0 ----------------------------
# Copyright 2009,  Lambert, Paletou, Josselin, Glorian
# GNU GENERAL PUBLIC LICENSE Version 3
# written by fpaletou@ast.obs-mip.fr (July 2009)
#         now fpaletou@irap.omp.eu (made public Oct 2015)
#
#--- please cite Lambert, Paletou, Josselin & Glorian, Eur. J. Phys.
#--- (arXiv:1509.01158) for any further use!
#
#--- references: http://cdsads.u-strasbg.fr/abs/1987JQSRT..38..325O
#                http://adsabs.harvard.edu/abs/1994A%26A...285..675A
#                http://cdsads.u-strasbg.fr/abs/1995ApJ...455..646T
#                http://adsabs.harvard.edu/abs/2003A%26A...411..221C
#                http://cdsads.u-strasbg.fr/abs/2007JQSRT.103...57P
#    (in french) http://tel.archives-ouvertes.fr/tel-00332781/
#
#--- aknowledgements: to my 'sensei' Larry H. Auer, and my friends
#                     Loic Chevallier and Ludovick Leger                
